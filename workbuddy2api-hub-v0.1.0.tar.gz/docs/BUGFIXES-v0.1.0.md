# WorkBuddy2API-Hub v0.1.0 · BUG 修复清单

> 本清单**严格对应 v0.1.0 的最终代码**。每条给出：症状 → 触发条件 → 根因 → 改法 → 证据位置。
> 「已修复」条目均已通过上游自带 225 个测试套件（`python tests/run_all.py`）与本项目自建的 3 个本地测试。
> 「已回退」条目是审计提出、但经回归证明是上游**刻意设计**的条目，保留记录以免后人重复踩。

- 基线：上游 `ardeyouxipianyi/workbuddy2api-hub @ d1a8913`（2026-10-24）
- 本地补丁层：`dashboard.html` / `wb_tasks.py` / `wb_scheduler.py` / `wb_proxy.py`
- 回归网：225 个套件（166 Python + 59 JS），`python tests/run_all.py --jobs 4`

---

## 一、审计范围与方法

按模块分区做只读审计（每个分区独立进行，避免基线判断互相污染）：

| 分区 | 范围 | 结论条数 |
|---|---|---|
| 分区 1 | `wb_proxy.py` 1–8000（基础设施/鉴权/用量统计/限额守卫） | 31 |
| 分区 2 | `wb_proxy.py` 8000–17000（上游调用/协议转换/重试/选号） | 39 |
| 分区 3 | `wb_proxy.py` 17000–23310（Anthropic/Responses 转换/HTTP 处理器/面板 API） | 39 + 11 条安全 |
| 分区 4 | 其余 28 个模块（账号池/凭据/配置/目录/计价/任务/工具） | 见附录 |

审计方法要求：每条结论必须给 `文件:行号` 并附关键代码片段；不确定的标「疑似」并写明不确定点；
找不到的写「未发现」并列出搜索关键词，**不允许断言某能力不存在**。

---

## 二、已修复清单

### 2.1 任务引擎（`wb_tasks.py`）

| # | 症状 | 触发条件 | 根因 | 修复 |
|---|---|---|---|---|
| T1 | **任务上报的桌面指纹与主对话链路自曝两个版本号**：任务链路说 5.5.6、主链路说 5.8.3 | 每次成长任务上报 | 补丁里把 `DESKTOP_UA` 硬编码成 `"WorkBuddy/5.5.6 … CLI/2.137.1"`，覆盖了同一文件顶部引用的 `wb_identity.DESKTOP_UA_CN` | 删除硬编码，UA 唯一真源改为 `wb_identity.DESKTOP_UA_CN`（国内版 5.8.3，2026-10-18 两区桌面端实跑记录） |
| T2 | **设备标识形态是「网关特征」**：machineId/sessionId 为 36 位裸 hex | 同上 | 补丁自建了 `_derive_device_id`（sha256 前 36 hex） | 改调上游 `wb_fingerprint.get_desktop_fingerprint()`：machineId/sessionId 为**带连字符 UUID**（官方客户端取自 OS 硬件 UUID / 进程 randomUUID） |
| T3 | **请求 id 含稳定前缀**：42 字符且前 36 位由 uid 派生 | 同上 | `X-Request-ID` 用了 `_derive_device_id(uid,"req")` + 6 位毫秒尾巴 | 改用上游 `wb_fingerprint.generate_request_id()`：32 位**每条随机** hex，不掺 uid（掺 uid 派生前缀本身就是一条稳定的网关特征） |
| T4 | **领奖判据可能在上游没记账时就去领奖**，必然吃 400 `task not completed` | `accept_status` 短暂变 `completed` 而进度未落账（awaiting_progress） | 判据是 `status == "completed" or cur >= tgt`，而 `status` 就是 `accept_status` | 判据改为只用 progress 口径：`if tgt > 0 and cur >= tgt`。依据 workbuddy2api-panel 的补领清扫（`internal/panel/tasksweep.go:3-5`、`internal/upstream/tasks.go:273`：`Claimable = !claimed && tgt > 0 && cur >= tgt`） |
| T5 | **「未知但已达标」的任务会抛 TypeError**，补领清扫链路整条崩 | 上游新增了不在 `TASK_SPECS` 里的任务，且它已达标 | 日志取 `spec['name']`，而未知任务的 `spec` 是 `None` | 日志统一用 `name` 变量（已知任务取表名，未知任务取上游返回的名字，再兜底 code） |
| T6 | **「未知任务」判断排在「已达标→领奖」之前**，陌生任务永远扫不进领奖队列 | 同上 | 两个分支顺序颠倒 | 领奖分支前移；未知任务分支保留但挪到其后。依据同款 Go 实现的「补领清扫」语义 |
| T7 | 账号对象缺少 `nickname` 属性时调度器整轮崩（`AttributeError`） | 上游测试的最小账号桩；真实场景是部分初始化的账号对象 | 4 处直接 `account.nickname` | 改为 `getattr(account, "nickname", "")` 兜底 |

### 2.2 调度器（`wb_scheduler.py`）

| # | 症状 | 触发条件 | 根因 | 修复 |
|---|---|---|---|---|
| S1 | **一个账号的任务抛异常，后面所有账号都不再跑** | 任一账号的签到/旅行/连登/成长任务抛出未捕获异常 | 账号循环内 8 处任务调用**全都没有 try/except**，异常直接冒泡出整轮巡检 | 每账号的任务块整体包一层 `try/except`，记一行日志后继续下一个账号（「这一轮没跑」与「跑了但这个账号失败」在日志里必须能区分开） |

> 这条是被上游测试 `_test_schedule_hours.py` 逼出来的：上游测试用的账号桩没有 `headers` 属性，
> 而成长队列在 01:00 轮被调用 → 暴露了「单账号失败打断整轮」这个一直存在、但此前无人触发的问题。

### 2.3 网关主文件（`wb_proxy.py`）

| # | 严重度 | 症状 | 触发条件 | 根因 | 修复 |
|---|---|---|---|---|---|
| P1 | 高 | **账号并发名额永久泄漏**：某账号的 `_ACCOUNT_INFLIGHT` 只增不减，累计到上限后该账号被永久踢出调度，面板只显示「无可用账号」 | 面板开启 `account_max_concurrent` 后，上游返回 HTTP 400 / 404 / 405 / 409 / 413 等未分类状态码 | 重试循环里 `except HTTPError` 的裸 `raise` **跳出整个 `while` 循环**，而名额归还写在循环之后 → 被跳过 | 两处裸 `raise`（400 透传、未分类状态码）之前先归还名额并清空标记 |
| P2 | 高 | **非法 UTF-8 请求体让处理线程永久挂起** | POST 带 `Content-Length: N`，body 含非 UTF-8 字节 | `.decode("utf-8")` 抛 `UnicodeDecodeError` 时 `_body_consumed` 仍是 `False`，而 body 已从 socket 读完 → `_discard_body()` 再读同一段 Content-Length → 永久阻塞 | 先记账再解码；解码改 `errors="replace"`（与 chunked 路径统一） |
| P3 | 高 | **Slowloris：连上不发数据即可无限占线程** | 任意 TCP 连接握手后不发请求行 | `Handler` 未设 `timeout`，`socketserver` 因此不 `settimeout`；`ThreadingHTTPServer` 每连接一线程且无上限 | `Handler.timeout = 60` |
| P4 | 高 | **`glm-5v-turbo` 完全无法被服务**：任何请求都返回「无可用账号」 | 请求该模型且未指定 realm | `detect_model_realm()` 的 cn_only 集合**漏了** `glm-5v-turbo` → 判成 intl；而它只有国内版出口提供；intl→cn 兜底又因 `exclusive_realm()` 判它是 cn-only 而拒绝 → 死路 | `detect_model_realm()` 改为查 `exclusive_realm()`（唯一事实源），删除自己那份互相矛盾的硬编码集合 |
| P5 | 高 | **`minimax-*` 被前缀一刀切钉到 cn 出口**，只有国际账号的部署直接失败且无法兜底 | 请求 `minimax-m3.1-flash` 等 | `detect_model_realm()` 用 `startswith("minimax-")` 一刀切，而 `exclusive_realm()` 认为它是双出口模型 | 同 P4，统一查表 |
| P6 | 中 | **流式与非流式给出的工具调用不一样**：流式会把没有 `function.name` 的 tool_call 透传给客户端（OpenAI SDK 直接抛错），非流式会剔除 | 上游在流末尾发 `tool_calls:[{function:{name:"",arguments:"{}"}}]` 占位 | `clean_chunk` 只处理 `function_call` 一种拼写，漏了 `tool_calls[].function.name` | 在 `clean_chunk` 里补上与非流式一致的过滤 |
| P7 | 中 | **客户端传 `n>=2` 时，后面 choice 的内容被整帧丢弃** | 上游真的回多条 choice，其中一条是空占位 | 早退写成 `return ""`（丢整帧）而不是 `continue`（只丢这条 choice） | 改为逐条丢弃；全部 choice 都是空占位时才丢整帧 |
| P8 | 中 | **客户端声明的服务端工具被静默改写成没有 name 的 function**，上游返回 11129/11101 或工具静默失效 | 面板 `local_web_tools` 关闭（默认）时客户端带 `tools:[{"type":"web_search"}]` | `else` 分支无条件把 `type` 改成 `"function"` | 只在 `type` **缺失**时补 `"function"`，其余类型原样透传 |
| P9 | 中 | **Responses 风格的 `input_text` 分片绕过指纹清洗** → 上游 11128 | 客户端把系统提示写成 `content:[{"type":"input_text",…}]` | `sanitize_content` 只认 `type == "text"` | 白名单补 `input_text` / `output_text` / `summary_text` |
| P10 | 中 | **SSE 首帧带 UTF-8 BOM 时整帧丢失** | 上游或中间 CDN 在首字节前加 BOM | BOM 不是空白字符，`strip()` 去不掉 → 该帧既不匹配 `data:` 也不匹配注释前缀 | `strip_data_prefix()` 额外 `lstrip("\ufeff")` |
| P11 | 中 | **429 正文里的重置时刻解析不出来** → 退化成「整个凭证冷却 60s→2h」而不是「只冷却该模型」 | 响应体同时含 `\uXXXX` 转义与原生 UTF-8 中文 | `unicode_escape` 按 latin-1 逐字节解码，原生中文变乱码 → 按「将在」匹配重置时刻永远失配 | 只在正文无非 ASCII 字符时整体解码；混合情况改为逐个还原 `\uXXXX` |
| P12 | 中 | **60 秒内单个账号可切换超过 4 次身分**（`MAX_PRODUCT_SWITCHES` 被绕过） | `_SWITCH_LOG` 累计到 500 条后触发全清 | 全清等于把所有账号的切换计数一起归零 | 改为 LRU 淘汰最老的一批 |
| P13 | 中 | **整池暂停（30 分钟）被面板「测试账号」按钮反复续期**，永远红着 | 暂停期间运营者点测试 | 每次触发都 `max(held, now + HOLD)` 往后推 | 暂停生效期间保持原到期时刻，不延长 |
| P14 | 中 | **一次环境变量笔误就让整个网关起不来**（`ImportError`，不是请求期失败） | `WB_MAX_PAYLOAD_BYTES=16m` / `WB_CHAT_SLOT_WAIT=30s` / `WB_AFFINITY_MAX_MSGS=400条` 等 | 模块级裸 `int()` / `float()` | 新增 `_env_int()` / `_env_float()` 容错助手（非法值回落默认），并替换全部 8 处裸解析 |
| P15 | 中 | **`PORT` 非数字时 argparse 之前直接崩**，只看到一串栈 | `PORT=abc` | `--port` 的 default 在 `parse_args()` 里求值，异常无人接 | 提前解析，给一句人话并 `SystemExit` |
| P16 | 中 | **面板上编辑任意一个 API Key 行并保存，会把该 Key 的并发上限静默清零** | 面板 → 设置 → API Key → 改名字 → 保存 | 前端总是提交 `concurrency_limit`，后端「字段缺省才沿用已存值」的保护因此失效 | 见附录「待办」（本轮未改，涉及前后端字段契约） |
| P17 | 低 | `gateway_hint` 把 requestId 里的数字串误判成账号风控 | 403 正文的 requestId 恰好含 "11140" | 裸子串匹配 | 改用结构化正则 `_RESTRICTED_403_CODE_RE` |
| P18 | 低 | `is_transient` 用裸数字子串判 5xx，端口号 / 请求 id 里的 "502" 会被当成网关错误 | 错误文本里恰好含这些数字 | 裸子串匹配 | 5xx 数字改成有边界的正则匹配 |
| P19 | 低 | `normalize_usage_cache_aliases` 尾部有一段**永远执行不到的死代码** | 无 | `return usage` 之后又写了一遍同样的逻辑 | 删除重复块 |
| P20 | 低 | `enrich_agent_models` 对非 dict 条目直接 `AttributeError` | 看板/客户端传 `models=["gpt-5.5"]` | `(item or {}).get("id")` 对字符串调用 `.get` | 非 dict 条目原样带过去 |
| P21 | 低 | `get_desktop_fingerprint()` 是**死代码**：定义了完整的 5.8.4 桌面指纹，全仓零调用 | 无 | 上游写了但没接 | 本地补丁改为调用它（见 T2） |
| P22 | 低 | `drop_truncated_tool_calls` 生产代码零调用，逻辑与内联版重复 | 无 | 复制粘贴 | 本轮未合并（见附录「待办」） |

---

## 三、已回退（审计提出但经回归证明是上游刻意设计）

| # | 审计提出的「缺陷」 | 回退原因 | 证据 |
|---|---|---|---|
| R1 | `estimate_tokens` 对纯中文凭空多算 1 个 token | 上游 `max(1, int(other/3.6))` 是**护栏**：1~3 字符的短请求不能估成 0 token | `_test_hotpath_savings.py::test_matches_the_character_loop` 逐字比对字符循环参考实现 |
| R2 | 登录限流在反代部署下可被 `X-Forwarded-For` 伪造绕过 | 上游**刻意支持**「只设 XFF 的反代形态」；伪造防护靠的是「非回环对端一律按 peer IP 分桶」，不是砍掉 XFF 回落 | `_test_login_ratelimit_proxy.py` 4 条用例（首跳取用、host:port 形态、畸形头回落链） |
| R3 | 工具结果与调用取交集 → 孤儿结果被整条丢弃 | 上游**刻意**剔除孤儿结果（有专门测试钉住） | `_test_upstream_repairs.py` 的「a result with no call is reported as a change」「the orphan result is removed」 |

> **这三条的残余风险**见安全审查报告 S-14：R2 的前提是反代必须**覆盖**（而非追加）`X-Real-IP`。

---

## 四、版本锁定

上游 CI（`.github/workflows/tests.yml` 的 `version-assert` 任务）要求：源码里的两处版本串必须一致，
且 release tag 必须等于源码版本。v0.1.0 沿用同一约束：

| 位置 | 改前 | 改后 |
|---|---|---|
| `wb_proxy.py` overview 的 `"version"` | `1.7.33` | **`0.1.0`** |
| `wb_proxy.py` 的 `server_version` | `wb-proxy/1.7.33` | **`wb-proxy/0.1.0`** |
| `VERSION` 文件 | 不存在 | **`0.1.0`** |
| `wrt/openwrt/workbuddy2api/Makefile` 的 `PKG_VERSION` | `1.7.33` | **`0.1.0`** |

---

## 五、附录：审计发现但本轮未修（按优先级排队）

### A 级（建议下一版处理，需要设计或跨前后端改动）

| # | 描述 | 出处 |
|---|---|---|
| A1 | **面板 Key 的 `concurrency_limit` 字段契约断裂**：后端 `runtime_settings_view()` 的 key 条目没有该字段 → 前端恒读成 0；前端又总是提交该字段 → 后端「缺省沿用已存值」的保护失效，保存即清零 | `wb_proxy.py` runtime_settings_view / `_handle_settings_save` |
| A2 | **`open_upstream` 660 行 / 7 个 except / 5 套并行状态**，是全文件最高风险改动点；P1 的名额泄漏正是它的结构问题 | `wb_proxy.py` 约 14600–15300 |
| A3 | **三套并行的上游帧清洗实现**（chat 流 / Responses 流 / 非流式聚合），同一套语义已经漂移出可复现的不一致 | `wb_proxy.py` 的 `clean_chunk` / `clean_responses_frame` / `aggregate_stream` |
| A4 | **模型归属仍有第三份事实源**（`wb_catalog` 的 `STATIC_*_MODELS`）。P4/P5 修好了 `detect_model_realm` ↔ `exclusive_realm`，但目录快照仍可能与这两张表不同步 | `wb_catalog.py` vs `wb_proxy.py` |
| A5 | **面板无按 API Key 维度的用量聚合**：日志逐行记了 `key`，但所有聚合口径都只按 model/realm/account 切分 → 多人共用网关时无法回答「哪个 Key 花了多少钱」 | `wb_proxy.py` 的 `_empty_stats` / `_fold_usage_snapshot` |
| A6 | **面板长耗时动作同步占用请求线程**（一键跑成长任务 / 一键测试 / 全部刷新），且可被并发重复触发 → 重复领取、重复打上游 | 面板任务/账号相关路由 |
| A7 | **`_handle_settings_save` 690 行 / 约 70 个平铺分支**；`Handler` 类 4612 行 / 约 80 个方法 | `wb_proxy.py` |
| A8 | **鉴权是两套并行判定**：`_is_panel_route` 白名单 + 逐路由自查 `_panel_ok()`，四档信任语义（公开 / API Key / 面板会话）交叉 | `wb_proxy.py` |

### B 级（低风险、可随手做）

| # | 描述 |
|---|---|
| B1 | `_pct` 定义后从未被调用（死代码） |
| B2 | `rewards_ran` 只赋值、从不被读（死代码） |
| B3 | `find_namespace_tool` / `NAMESPACE_TOOL_MESSAGE` / `REJECT_NAMESPACE_TOOLS` 三个符号全仓零引用 |
| B4 | `drop_truncated_tool_calls` 生产路径零调用，与内联实现重复 |
| B5 | `_perf_stats_uncached` 与 `_perf_payload` 是两份同构的渲染代码 |
| B6 | 窗口折叠口径三份重复，`since` 判空口径不统一（`if since` vs `if since is not None`） |
| B7 | 跨天归档先写 `state["day"]` 再做归档，归档异常时该天被永久跳过 |
| B8 | 写盘临时文件名固定（`X.tmp`），两个进程共用同一目录会互相踩 |
| B9 | `GET /logs` 的 `limit` 未夹上限（对比 `/usage/recent` 有 `min(1000,…)`） |
| B10 | `POST /accounts/delete` 对不存在的 uid 也返回 200 |
| B11 | `GET /accounts/credits/detail?uid=<不存在>` 静默回退到账号池第一个账号（面板显示的是别人的数据） |
| B12 | `--import-desktop` 不会退出（帮助文本写的是 "then exit"） |
| B13 | `/v1/responses` 与 `/v1/chat/completions` 流式响应在上游未回 usage 时，prompt_tokens 被**猜**（恒 1 或 completion 的半数） |

---

## 六、验证方式

```sh
cd release
python tests/run_all.py --jobs 4 --logs suite-logs   # 225 个套件
```

本项目自建的三个本地测试（补丁层的回归网）：

```sh
python deploy/test_task_patch.py       # 任务引擎补丁，40+ 断言
python deploy/test_log_mask.py         # 运行时凭据脱敏，15 断言
node   deploy/test_multifile_import.js # 面板多选导入，13 断言
```

三个本地测试都带**控制组**：拿纯净上游的同名文件去跑必须失败，否则测试不敏感。

```sh
python deploy/test_task_patch.py _src/workbuddy2api-hub-main   # 必须 exit 1
python deploy/test_log_mask.py   _src/workbuddy2api-hub-main   # 必须 exit 1
```
