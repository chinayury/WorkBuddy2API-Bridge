# WorkBuddy2API-Hub v0.1.0

> 把**多个**腾讯 WorkBuddy / CodeBuddy 账号变成一个 **OpenAI 兼容接口**，
> 并把账号的**成长任务中心**自动化跑完。

- **纯标准库**：31 个 Python 模块 + 1 个单文件前端面板，**零第三方依赖**
- **OpenAI 兼容**：`/v1/chat/completions`、`/v1/models`、`/v1/responses`、`/v1/messages`
- **账号池**：加权选号、冷却退避、模型级冷却、账号级风控识别、并发名额
- **任务自动化**：桌面端 / 网页端指纹事件链点亮「需电脑端」任务，每日 01:00 自动领奖
- **Web 面板**：单文件 vanilla 前端，零外部 CDN
- **自带回归网**：225 个上游套件 + 3 个补丁层测试（每个都带控制组）

---

## 一、它解决什么问题

腾讯 WorkBuddy / CodeBuddy 的账号各自有额度与成长任务，但客户端一次只连一个账号。
直接用官方客户端会遇到：

1. **额度用完就停** —— 没有账号池轮换
2. **成长任务要手点** —— 每天几百积分，不点就丢
3. **客户端限流/风控** —— 单号被打挂就没了

本项目把 N 个账号聚成一个 OpenAI 兼容端点，并顺手把任务中心自动化：

```
   Codex / Claude Code / DSH / Cherry Studio / 任何 OpenAI 兼容客户端
                              │  Bearer <API Key>
                              ▼
        ┌───────────────────────────────────────────────┐
        │  WorkBuddy2API-Hub v0.1.0                     │
        │   · 账号池：加权轮询 / 冷却退避 / 模型级冷却    │
        │   · 协议转换：OpenAI / Responses / Anthropic   │
        │   · 任务引擎：指纹事件链 → 接取 → 上报 → 领奖   │
        │   · 调度器：签到 / 猫猫旅行 / 成长 / 保活       │
        │   · 面板：账号池 / 用量 / 任务 / 设置          │
        └───────────────┬───────────────────────────────┘
                        │  Bearer <账号 token>
                        ▼
              腾讯上游（copilot.tencent.com / www.workbuddy.ai）
```

---

## 二、代码规模（v0.1.0 实测）

| 模块 | 总行 / 有效行 | 职责 |
|---|---|---|
| `wb_proxy.py` | 23463 / 18678 | 主网关：HTTP 服务、路由、鉴权、协议转换、SSE 桥接、用量记账、面板托管 |
| `wb_accounts.py` | 5294 / 4263 | 账号池、凭据、冷却、权重、签到、活跃上报、额度估算 |
| `wb_settings.py` | 3070 / 2359 | 面板设置持久化（`settings.json`）、面板会话、API Key |
| `wb_pricing.py` | 2620 / 2186 | 计价表与成本估算 |
| `wb_agents.py` | 1805 / 1482 | 客户端（DSH / Crush / Claude Code…）配置生成 |
| `wb_catalog.py` | 1732 / 1722 | 模型目录与档位 |
| `wb_tasks.py` | 1218 / 1000 | **成长任务引擎**（含本地补丁：指纹事件链、专家 id 通用解析） |
| `wb_webtools.py` | 1100 / 910 | web 搜索多引擎（DDG / Bing / StackExchange / GoogleNews）与冷却 |
| `wb_update_portable.py` | 953 / 807 | 便携版 / Windows 版的更新与重启 |
| `wb_atrest.py` | 916 / 727 | 纯 Python AES-256-GCM 静态加密 + 子进程扫描桌面端密钥 |
| `wb_upstream_pool.py` | 853 / 653 | 上游 HTTP 连接池与租约 |
| `wb_scheduler.py` | 805 / 651 | **后台调度器**（含本地补丁：01:00 成长任务队列） |
| `wb_identity.py` | 642 / 440 | 三套出站身份：桌面 / VSCode 扩展 / CodeBuddy CLI |
| 其余 18 个模块 | — | 额度扫描、窗口探针、活动历史、日志库、更新执行器、提示词、档位、出口、指纹等 |
| **合计（31 模块）** | **48804 / 39446** | |
| `dashboard.html` | 18011 行 / 986 KB | 单文件前端面板 |
| `tests/` | 245 个文件 | 225 个可执行套件 |

---

## 三、模块地图

```
                     ┌──────────────┐
   HTTP 请求 ───────▶│  wb_proxy.py │  路由 / 鉴权 / 协议转换 / 记账 / 面板托管
                     └──┬────────┬──┘
        ┌───────────────┘        └────────────────┐
        ▼                                         ▼
┌─────────────────┐                    ┌──────────────────┐
│  wb_accounts.py │ 账号池/凭据/冷却   │ wb_upstream_pool │ 连接池/租约
│  wb_settings.py │ 设置/会话/Key      │ wb_identity.py   │ 三套出站身份
│  wb_atrest.py   │ 静态加密          │ wb_fingerprint.py│ 设备指纹派生
└─────────────────┘                    └──────────────────┘
        ┌──────────────────────┐          ┌────────────────────┐
        ▼                      ▼          ▼                    ▼
┌─────────────────┐   ┌────────────────┐  ┌──────────┐  ┌──────────────┐
│  wb_tasks.py    │   │ wb_scheduler.py│  │wb_catalog│  │ wb_webtools   │
│  成长任务引擎    │◀──│  整点调度      │  │wb_pricing│  │ web 搜索引擎  │
└─────────────────┘   └────────────────┘  │wb_tiers  │  └──────────────┘
                                           └──────────┘
```

---

## 四、运行时模型

| 维度 | 事实 |
|---|---|
| 进程 | **单进程**。`ThreadingHTTPServer`，每连接一线程，`daemon_threads` |
| 连接上限 | `request_queue_size = 128`（请求队列，不是连接数）；**v0.1.0 起每连接 60 秒 socket 超时**（Slowloris 防护） |
| 调度线程 | 3 条常驻 daemon 线程：主循环、窗口探针、额度扫描 |
| 账号级锁 | 每个账号 5 把细粒度锁：额度 / 余额 / 节流 / 刷新 / 落盘，注释明确说明三者互不嵌套 |
| 落盘 | 「唯一临时名 + 原子 replace」，避免两个线程互相截断 |
| 写日志 | 同源脱敏后同时进 stderr 与看板缓冲；可选落 SQLite |
| 子进程 | 仅 1 个：静态加密模块在**其他进程内存**里扫描桌面端密钥（绿色包内置的精简 Python 没有 `multiprocessing`） |
| 更新器 | 独立的 root 服务，面板只能「排队一个 tag」，实际写入由它复核后执行 |

---

## 五、v0.1.0 相对上游的改动

| 类别 | 改动 |
|---|---|
| **新增功能** | 运行时凭据脱敏 · 「需人工」任务状态 · 导入多选合并 · 桌面/网页指纹事件链 · 专家 id 通用解析 · 01:00 成长任务队列 · 超大工具定义压缩（Kimi 11133） |
| **修复** | 并发名额永久泄漏 · 非法 UTF-8 请求体挂死线程 · Slowloris 无超时 · `glm-5v-turbo` 完全不可达 · `minimax-*` 出口判定错误 · 流式/非流式工具调用不一致 · 服务端工具被改写成无名 function · 指纹清洗被 `input_text` 绕过 · BOM 丢首帧 · 429 重置时刻解析失败 · 切换次数上限被绕过 · 整池暂停被反复续期 · 环境变量笔误导致启动崩溃 · 调度器单账号失败打断整轮 · 未知任务抛 TypeError |
| **重构** | 出口判定统一到单一事实源 · 环境变量解析统一容错助手 · 调度器单账号任务隔离 · 帧清洗三路对齐 · body 记账顺序修正 |
| **部署形态** | bind-mount 补丁层 → **自包含镜像**（`FROM 官方 digest + COPY 补丁`）；版本锁定 `0.1.0`；发布树 + 回归网 + 全套文档 |

详见 [CHANGELOG-v0.1.0.md](CHANGELOG-v0.1.0.md)。

---

## 六、能力边界（诚实声明）

**能做**

- 多账号聚合成一个 OpenAI 兼容端点，自动选号、换号、冷却退避
- 成长任务中心全自动：接取 → 事件上报 → 领奖
- 用量统计与成本估算（按 OpenRouter 公布价折算）
- 面板管理账号、凭据、出口、限额、别名

**不能做 / 有前提**

| 项 | 说明 |
|---|---|
| `unforgeable` 任务 | 需真人操作（如关注公众号满 24 小时），**接口伪造不了**。面板会显示「需人工」并写明原因；真人做完后续轮自动补领 |
| Anthropic Messages | **默认关闭**（不透传 `cache_control`，打开可能白烧积分）。需显式 `WB_ENABLE_ANTHROPIC_MESSAGES=1` |
| 客户端代跑 `web_search` | **默认关闭**。关闭时客户端声明的服务端工具原样透传给上游，上游无执行器 |
| 跨出口回退 | **单向**：国际 → 国内可以，国内 → 国际不行（避免欠费时白烧国内额度） |
| 上游接口 | **全部是逆向所得**，非官方公开 API。客户端升级 / 字段改名 / 加风控都可能让某条链路立刻失效。无 SLA |
| 多副本 | 账号池状态在内存 + 本地文件，**不是分布式锁语义**。多副本会各选各的号，额度与在途限制形同虚设 |
| 凭据落盘 | 账号 token 与 API Key **明文**存在 `accounts/`（上游设计如此，为支持跨机导入）。靠目录权限兜底 |
| 账号级风控 | 上游 403 / code 11140 时**立即停手**，不换号继续打同一台设备（否则设备指纹连坐）。固定 2 小时且持久化 |

---

## 七、快速开始

```sh
# 1) 取源码
git clone https://github.com/ardeyouxipianyi/workbuddy2api-hub.git && cd workbuddy2api-hub

# 2) 配置面板密码（不要用默认 admin）
cd release
PANEL_PWD=$(python3 -c "import secrets;print(secrets.token_urlsafe(24))")
echo "PANEL_PASSWORD=$PANEL_PWD" > .env && chmod 600 .env

# 3) 构建并启动
docker build -t workbuddy2api-hub:0.1.0 .
docker compose up -d

# 4) 验收
curl -s http://127.0.0.1:8788/health
```

详细步骤见 [DEPLOY-v0.1.0.md](DEPLOY-v0.1.0.md)。

---

## 八、文档

| 文档 | 内容 |
|---|---|
| [DEPLOY-v0.1.0.md](DEPLOY-v0.1.0.md) | 环境部署教程（Docker / 免 Docker / 参数表 / 升级回滚 / FAQ） |
| [USAGE-v0.1.0.md](USAGE-v0.1.0.md) | 功能使用说明（面板 6 分区、69 个后端路径、任务自动化边界、常见操作流程） |
| [BUGFIXES-v0.1.0.md](BUGFIXES-v0.1.0.md) | BUG 修复清单（症状 / 触发条件 / 根因 / 改法）+ 审计发现但未修的排队清单 |
| [CHANGELOG-v0.1.0.md](CHANGELOG-v0.1.0.md) | 功能优化与新增日志、兼容性变化、版本路线图 |
| [SECURITY-v0.1.0.md](SECURITY-v0.1.0.md) | 安全审查报告（供应链、已修复问题、残余风险、渗透测试、加固清单） |
| 上游 `README.md` | 上游项目的完整说明（127KB，含各功能的详细口径） |
| 上游 `docs/CHANGELOG.md` | 上游版本变更记录 |

---

## 九、许可与来源

本项目基于上游 [`ardeyouxipianyi/workbuddy2api-hub`](https://github.com/ardeyouxipianyi/workbuddy2api-hub)
（MIT）继续开发，保留上游版权声明。

第三方引用（实现思路来源）：

| 项目 | 借鉴内容 |
|---|---|
| `linguo2625469/workbuddy2api-panel` / `misakano7545/workbuddy2api-panel` | 桌面端/网页端指纹事件链、任务中心自动化、补领清扫语义 |
| `wushuai0802/workbuddy2api-hub-ops-patch` | 运维补丁线的「可检查、可回退」工程做法（BASELINE 指纹锁 + apply.py + 分层回归） |
| `flyouting/Buddy2api` | 本机客户端登录态读取与 `$wbEncrypted` 加密信封的处理思路 |
| `CangShui/workbuddy-gateway` | 运行时凭据脱敏（登记真实值 + 长值优先一次替换） |
| `jjjane233/workbuddy-3in1` | 错误分类阶梯、请求级 fail-fast 的思路 |

> ⚠️ **上游接口全部是逆向所得，非官方公开 API。** 客户端升级、字段改名、上游加风控，
> 都可能让某条链路立刻失效。本项目没有 SLA，不承诺兼容期。
> 账号风控、限流、封禁由腾讯侧决定，请勿用主账号运行。
